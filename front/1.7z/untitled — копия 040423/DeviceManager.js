const net = require('net');
const CRC32 = require("crc-32");
let List = require("collections/list");
const Emitter = require("events");
const converter = require("hex2dec");
const {decToHex, hexToDec} = require("hex2dec");
const {ProgramManager} = require("./ProgramManager");
const {observableArrayProperties} = require("collections/listen/array-changes");
const DeviceManager=
    {
        "devices": {},
        "tcpSockets": {},
        "programs":{},
        "programPackCicl":{},
        "programCounter":100,
        "errors":{},
        "emitter":"",
        "listers":new List(),

        addDevice(device,program)
        {
            let nd=device._id;


            this.devices[nd]=device;
            this.devices[nd]['receiver']=new List();
            this.programs[nd]=new List();
            this.programPackCicl[nd]=new List();
            if(Object.keys(program).length>0)
            {
                this.AddProgram(program);
                //this.programPackCicl[nd]=this.programs[nd].peek();

            }
           //this.devices[nd]['events']=new Event("readyToSend");
            this.emitter=new Emitter();
            //this.listers=new List();
            this.emitter.on("readyToSend",this.ReadyToSend);
            this.emitter.on("errorDevice",this.ErrorDevice);
            //this.emitter.on("programActualNow",this.ProgramActualNow);
            this.devices[nd]['hendlers']= {};
            this.tcpSockets[nd]=new net.Socket();
            //this.tcpSockets[nd].setTimeout(500);//вочдог таймаут
            this.tcpSockets[nd].on('timeout',()=>{console.log("timeout");/*this.tcpSockets[nd].end();*/});
            this.tcpSockets[nd].on('close',()=>
            {
                console.log("IN CLOSE SOCKET");/*this.tcpSockets[nd].end();*/
                this.emitter.emit("errorDevice",nd,"error Device Close Socket");
                setTimeout(()=>
                {
                    this.tcpSockets[nd].connect(this.devices[nd].port,this.devices[nd].ip,()=>
                    {
                        console.log("IN CONNECT SOCKET");

                    });
                },500);

            });
            this.tcpSockets[nd].on('ready',()=> {

                console.log("IN READY SOCKET");
                setInterval(()=>
                {
                    DeviceManager.ChekProgramList(nd);
                },10);

            });
            this.tcpSockets[nd].on('error',(e)=>
            {
                console.log("error");/*this.tcpSockets[nd].end();*/
                console.log(e);
                this.errors=e;
            });
            this.tcpSockets[nd].on("data",(data)=>
            {
                console.log("indata dev:"+nd);
                let ds=Buffer.from(data, 'hex').toString("hex");
                let dec;
                let parsed;
                try
                {
                    if(this.devices[nd].interfaceConnect==="ModbusTCP") parsed=this.ParseModbusTCP(ds);

                    if(parsed.tcpcount=="0001")
                    {
                        //записать ответ разовой команды
                    }
                    if(hexToDec(parsed.tcpcount)>=100)
                    {
                        let programPack=this.GetProgramPackByModbusAnswer(parsed.tcpcount);
                        let archiveRecord= "false";
                        if(Object.hasOwn(programPack,"lastArchive") )
                        {
                            let test=Date.now()-programPack.lastArchive;
                            if(Date.now()-programPack.lastArchive>Number(programPack.periodArchive))
                            {
                                programPack.lastArchive=Date.now();
                                archiveRecord="true";
                            }
                        }
                        else
                        {
                            programPack.lastArchive=Date.now();
                            archiveRecord="true";
                        }

                        this.devices[nd].receiver.push({type:"programCycl","programPackId":programPack._id,"p":ds,"t":Date.now(),"d":parsed.dec,"archiveRecord":archiveRecord});
                        this.emitter.emit("readyToSend",nd);
                    }
                }
                catch (e){console.log(e);}




            });
            this.tcpSockets[nd].connect(this.devices[nd].port,this.devices[nd].ip,()=>
            {


            });
            /*if(this.devices[nd].programPacket.periodTime>0)
            {
                this.devices[nd].handlers=setInterval(()=>{
                    //console.log( this.tcpSockets[nd].closed);
                    if(!this.tcpSockets[nd].closed)
                    {
                        //console.log("inconnecting "+nd);
                        let pakkhex=Buffer.from(this.devices[nd].programPacket.str, "hex");
                        this.tcpSockets[nd].write(pakkhex);
                        //console.log(this.devices[nd].receiver);
                    }
                    else
                    {
                        //console.log("inNOOtconnecting"+nd);
                        this.devices[nd].receiver.push({"e":this.tcpSockets[nd]["_writableState"].errored,"t":Date.now()});
                        this.tcpSockets[nd].connect(this.devices[nd].port,this.devices[nd].ip);
                    }
                },this.devices[nd].programPacket.periodTime);
            }
            */
        },
        ChekProgramList(nd)
        {


            if(DeviceManager.programs[nd].length>0)
            {
                    let prog=DeviceManager.GetNextProgramFromActiveList(nd);
                    console.log(prog.message);
                    //this.tcpSockets[nd].write("008800000006010300000001");
                    let pakkhex = Buffer.from(prog.message, "hex");
                    this.tcpSockets[nd].write(pakkhex);

            }
        },
        AddProgram(programs)
        {
            if(Object.hasOwn(programs,"userId"))
            {
                let program=programs;
                if(program["type"]=="ModbusTCP")
                {
                    const buf = Buffer.allocUnsafe(2);
                    buf.writeUInt16BE(Number(this.programCounter), 0);
                    program["tcpnum"]=buf.toString('hex');
                    let str= program["message"];
                    let numpak=program["tcpnum"];
                    const regex = /^..../i;
                    program["message"]=str.replace(regex, numpak);
                    this.programCounter++;
                    if( this.programCounter==65534) this.programCounter=100;

                }
                this.programPackCicl[program.deviceId].push(program);
                this.programs[program.deviceId].push(program);
            }
            else
            {
                for (let p in programs)
                {
                    let program = programs[p];
                    if (program["type"] == "ModbusTCP") {
                        const buf = Buffer.allocUnsafe(2);
                        buf.writeUInt16BE(Number(this.programCounter), 0);
                        program["tcpnum"] = buf.toString('hex');
                        let str = program["message"];
                        let numpak = program["tcpnum"];
                        const regex = /^..../i;
                        program["message"] = str.replace(regex, numpak);
                        this.programCounter++;
                        if (this.programCounter == 65534) this.programCounter = 100;

                    }
                    this.programPackCicl[program.deviceId].push(program);
                    this.programs[program.deviceId].push(program);
                }
            }
            console.log("Programs added")
        },
        GetNextProgramFromActiveList(deviceId)
        {

            let prog=this.programs[deviceId].shift();
            if(prog.periodTime>0 && prog.actual==true)
            {
                setTimeout(this.AddProgramInList,prog.periodTime,deviceId,prog);
            }
            return prog;
        },
        GetProgramPackByModbusAnswer(pakTcpNum)
        {
            let result="";

            for(let prog in DeviceManager.programPackCicl)
            {
                let arr;
                try {
                     arr = DeviceManager.programPackCicl[prog].toArray();
                }catch(e)
                {console.log(e)}
                for(i=0;i<DeviceManager.programPackCicl[prog].length;i++)
                {
                   // let program=arr[i].tcpnum;
                    if(arr[i].tcpnum==pakTcpNum)
                    {
                        result=arr[i];
                        break;
                    }
                }


            }
            return result;
        },
        AddProgramInList(deviceId,program)
        {

            DeviceManager.programs[deviceId].push(program);
        },
        addOncePacket(deviceId,packet)
        {
            console.log( "addOncePacket");
           //console.log(DeviceManager.tcpSockets[deviceId].closed);
            let con=new net.Socket();
            con.setTimeout(500);
            con.connect(DeviceManager.devices[deviceId].port,DeviceManager.devices[deviceId].ip,()=>
            {

                    const pakkhex = Buffer.from(packet, "hex");
                    DeviceManager.tcpSockets[deviceId].write(pakkhex);


            });
            con.end();
            delete con;
        },
        ReadyToSend(_id)
        {
            let ar=DeviceManager.listers.toArray();
            for(let f in ar)
            {
                if(ar[f].event=="readyToSend")
               ar[f].func(_id);
            }

        },
        ErrorDevice(_id,error)
        {
            let ar=DeviceManager.listers.toArray();
            for(let f in ar)
            {
                if(ar[f].event=="errorDevice")
                    ar[f].func(_id,error);
            }
        },
        AddFuncListener(func,event)
        {
            DeviceManager.listers.push({func:func,event:event});
        },
        getHashIdAllDevices()
        {
            let id="";
            for( device in this.devices)
            {
                id=id+this.devices[device]._id;
            }
            //console.log("IN getHashIdAllDevices");
            //console.log(id);
            return CRC32.str(id);
        },
        getIdDevices()
        {
            let count=0;
            let result={};
            for( let device in this.devices)
            {
                result[count]=this.devices[device]._id;
                count++;
            }
            return result;
        },
        ParseModbusTCP(pak)
        {
            let reg=/(....)(....)(....)(..)(..)(..)(.*)/;
            let rg=pak.match(reg);
            let parsed={
                tcpcount:rg[1],
                length:rg[3],
                adress:rg[4],
                func:rg[5],
                countbyte:rg[6],
                hex:rg[7],
                dec:converter.hexToDec(rg[7])
            }
            //console.log(rg);
            return parsed;
        },
        ChangeProgramActualState(deviceId,programId,actual)
        {
            let result="ok";
            if(DeviceManager.programPackCicl[deviceId]!=undefined )
            {
                let programList=DeviceManager.programPackCicl[deviceId].peek();
                let array=DeviceManager.programPackCicl[deviceId].toArray();
                if(array.length>0)
                {
                    for(let el in array)
                    {
                        if(array[el]._id==programId)
                        {
                            result="ok";
                            array[el].actual=actual;
                            if(actual==true)
                            {
                                DeviceManager.AddProgramInList(deviceId,array[el])
                            }
                            return result;
                        }
                        else
                        {
                            result="error";
                        }
                        console.log(el);
                    }
                }
                else
                {result="error";}

            }
            else
            {
                result="error";
            }
            return result;
        },
        //AddListnerFuncReadyToSend()
        readToJSONStringAndDelDevice()
        {


        }

    }

   module.exports.DeviceManager=DeviceManager;