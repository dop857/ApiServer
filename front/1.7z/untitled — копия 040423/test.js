let s="63ff11c247bb8b28752d86da";
console.log(s);



/*const xxHash3 =require('xxhash-addon').XXHash3;
const salute = 'socket= new net.Socket();\n' +
    'socket.on("error",()=>console.log("error"));\n' +
    'socket.on("close",()=>console.log("close"));\n' +
    'socket.on("data",()=>console.log("data"));\n' +
    'socket.on("ready",()=>console.log("ready"));\n' +
    'socket.on("connect",()=>console.log("connect"));\n' +
    'socket.connect(23,"127.0.0.1",()=>';
const buf_salute = Buffer.from(salute);

console.log(xxHash3.hash(buf_salute).toString('hex'));
//console.log()

*/

//data={"dfdsf":"d"};
//fetch('http://127.0.0.1:80/receiver/station/regNew',{method: 'POST',headers:{'Accept': 'application/json, text/plain, */*','Content-Type': 'application/json'},body: JSON.stringify(data)
//}).then((res)=>{
//    console.log(res);
//});



/*
let str= "008800000005010302c27a";
let numpak="0001";
const regex = /^..../i;
str.replace(regex, numpak);
console.log(str.replace(regex, numpak));*/
/*
const buf = Buffer.allocUnsafe(2);

buf.writeUInt16BE(Number(255), 0);

//console.log(Number(256).toString(16,));
console.log(buf.toString('hex'));
*/
/*const net = require('net');
socket= new net.Socket();
socket.on("error",()=>console.log("error"));
socket.on("close",()=>console.log("close"));
socket.on("data",()=>console.log("data"));
socket.on("ready",()=>console.log("ready"));
socket.on("connect",()=>console.log("connect"));
socket.connect(23,"127.0.0.1",()=>
{
    console.log("connect start");

});*/

//console.log(obj.addDevice);


/*let List = require("collections/list");
let list = new List();
let data={};
for(let i=0;i<10;i++)
{
    list.add("l"+i);
}
*/
/*
console.log(list.toJSON());
for(let i=0;i<5;i++)
{

    console.log(list.shift());
}
console.log(list.toArray());

/*
fetch("http://127.0.0.1:80/receiver/test",{method: "POST",headers:{'Accept': 'application/json, text/plain, *','Content-Type': 'application/json'},body: data
}).then((res)=>
{
    console.log(res);
    /*res.json().then((resp)=>{
        for(let dev in resp)
        {
            console.log(resp[dev]);
        }
}})
    //console.log(res.body);
.catch(function (error)
{
    console.log("errrr");
    // ... ошибки.
});*/