'use strict';
//import net from "net";
const DeviceManager=require("./DeviceManager").DeviceManager;
const ServerManager=require("./ServerManager").ServerManager;
const ParsingAnswers=require("./ParsingAnswers").ParsingAnswers;
const net = require('net');
const fs=require("fs/promises");

let config={};

fs.readFile('./config.json', { encoding: 'utf8' }).then((contents)=>
{
    config = JSON.parse(contents);

    if(config._id=="")
    {
        let data=config;
        fetch("http://"+config.server+":"+config.port+config.entryPoint+'/station/regNew',
            {method: "POST",headers:{'Accept': 'application/json, text/plain, */*','Content-Type': 'application/json'},
                body: JSON.stringify(data)}).
        then((res)=>
        {
            res.text().then((r)=>{
                r=JSON.parse(r);
                console.log(r["_id"]);
                config._id=r["_id"];

                fs.writeFile('./config.json',JSON.stringify(config)).then(()=>{
                    StartInit();
                })


            }).catch((err)=>
            {
                console.error(err.message);
            });
        });
    }
    else
    {

        StartInit();
    }



});


function StartInit()
{
    ServerManager.Construct(config.server,config.port,config._id,ParsingDataFromServer);
    DeviceManager.AddFuncListener(ListenerReadyFromModbus,"readyToSend");
    DeviceManager.AddFuncListener(ListenerErrorDevice,"errorDevice");
    setInterval(()=>{StationIsActive();},config.interval);
}


function StationIsActive()
{
    const data=JSON.stringify({"stationId": config._id,"lastActive": Date.now().toString(),"interval": config.interval});
    ServerManager.SendData("/receiver/station",data,"POST");
    //console.log(Object.keys(ServerManager.answers).length);

}

function ParsingDataFromServer()
{
    //console.log(ServerManager.answers.toArray());
    ParsingAnswers(ServerManager);

}
function ListenerReadyFromModbus(_id,)
{
    //console.log("IN LSISTNER READY FROM MODBUS");
    let dev=DeviceManager.devices[_id];
    let rec=dev.receiver.shift();
    if(rec.type=="programCycl") {
        let data =
            {
                currentData: {
                    type: rec.type,
                    programPackId: rec.programPackId,
                    pack: rec.p,
                    date: rec.t,
                    dec: rec.d
                },
                archiveRecord:rec.archiveRecord,
                deviceId:_id
            }
        console.log(data);
        ServerManager.SendData("/receiver/packet",JSON.stringify(data),"POST");
    }

}
function ListenerErrorDevice(_id,error)
{
    ServerManager.SendData("/receiver/error",JSON.stringify({_id:_id,error:error}),"POST");
}












