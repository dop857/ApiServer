const {ServerManager} = require("./ServerManager");
const {DeviceManager} = require("./DeviceManager");
const {decToHex} = require("hex2dec");

function ParsingAnswers(ServerManager)
{
    //console.log("IN ParsingAnswers");
    let ListAnswers=ServerManager.answers;

    while(ListAnswers.length>0)
    {
        let answer=ListAnswers.shift();
        try
        {
            let ans=JSON.parse(answer);
            //console.log(ans);
            if(Object.hasOwn(ans,"comand")){
                for(let com in ans.comand)
                {
                   // console.log(ans.comand[com].comand);
                    let comandjs=JSON.parse(ans.comand[com].comand);
                    //console.log(comandjs);
                    //console.log(Object.keys(comandjs));
                    switch (Object.keys(comandjs).at(0))
                    {
                        case "addDevice":
                            ServerManager.SendData("/receiver/device",JSON.stringify(comandjs.addDevice),"POST");
                        break;

                        case "verification":
                            //console.log("IN verification");
                            //console.log(DeviceManager.getIdDevices());
                            ServerManager.SendData("/receiver/device/verification",JSON.stringify({idDevices:DeviceManager.getIdDevices()}),"POST");

                        break;
                        case "addProgram":
                            console.log("IN addProgram");
                            //console.log(DeviceManager.getIdDevices());
                            //ДОПИСАТЬ проверку для возможной ситуации создания команды во время неактивности станции
                            if(  Object.keys(comandjs.addProgram).length>0  )
                            ServerManager.SendData("/receiver/getProgram",JSON.stringify({_id:comandjs.addProgram}),"POST");

                            break;
                        case "addOnceProgramPacket":
                            console.log("addOnceProgramPacket");
                            let idDM=DeviceManager.getIdDevices();
                            for(let i in idDM)
                            {
                                if(idDM[i]==comandjs.addOnceProgramPacket.deviceId)
                                {
                                    let id=comandjs.addOnceProgramPacket.deviceId;
                                    console.log(id);
                                    console.log(comandjs.addOnceProgramPacket.packet);
                                    let program={str:comandjs.addOnceProgramPacket.packet};
                                    DeviceManager.AddProgramInList(id,program);
                                    //DeviceManager.addOncePacket(id,comandjs.addOnceProgramPacket.packet);


                                }
                            }

                            //ServerManager.SendData("/receiver/device",JSON.stringify(comandjs.addDevice),"POST");
                        break;
                        case "changeActualProgram":

                            DeviceManager.ChangeProgramActualState(comandjs.changeActualProgram.deviceId,comandjs.changeActualProgram.programPackId,comandjs.changeActualProgram.actual);
                        break;
                    }

                }
            }
            if(Object.hasOwn(ans,"device"))
            {
                console.log("DEVICE DETECTED FO ADD");
                DeviceManager.addDevice(ans.device[0],ans.program);
                //console.log(DeviceManager.devices);
            }
            if(Object.hasOwn(ans,"programPack"))
            {
                console.log("Program detected FOR ADD");
                DeviceManager.AddProgram(ans.programPack);
                console.log(ans.programPack);
            }
        }
        catch (e)
        {
            console.log(e);
        }


    }

    //ServerManager.SendData("/receiver/comand")
   /* let jsobj=JSON.parse(res);
    if(Object.hasOwn(jsobj,"devices")){
        for(let dev in jsobj.devices)
        {
            console.log(jsobj.devices[dev]);

        }
    }
    console.log("in ServerManager ParsingAnswer");
    console.log(devices);*/


}

module.exports.ParsingAnswers=ParsingAnswers;